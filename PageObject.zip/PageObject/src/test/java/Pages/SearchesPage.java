package Pages;

import org.openqa.selenium.By;

public class SearchesPage extends BasePage {

    private By mpnField = By.cssSelector("#search-mpn-field");
    private By eanField = By.cssSelector("input[id='search-ean-field']");
    private By searchButton = By.cssSelector("#searchButton");
    private By customSearchButton = By.cssSelector("div#toggle-custom-product-search>section>section>section>div#box-grid>span>button#searchButton");
    private By mpnColumninSearchResults = By.cssSelector("td[aria-describedby='list47_mpn']");
    private By selectFileButton = By.cssSelector("input[id='fileToUpload']");
    private By mpnDropdowninCustomSearch = By.cssSelector("select[name='mpn']");



    public void searchByMpn() throws InterruptedException {
        writetoField(mpnField, "VGP");
        chooseFromAutoSuggest("VGPAC10V10.CEL");
        click(searchButton);
        verifyFieldsContainsText(mpnColumninSearchResults, "VGPAC10V10.CEL");
        goToLandingPage();
    }

    public void searchByEan() throws InterruptedException {
        writetoField(eanField, "0854448003723");
        click(searchButton);
        verifyFieldsContainsText(mpnColumninSearchResults, "S3000BWGB");
        goToLandingPage();
    }

    public void customSearch() throws InterruptedException {
        writetoField(selectFileButton, "C:\\Assets\\Custom_product_search.xlsx");
        writetoField(mpnDropdowninCustomSearch, "Column B");
        click(customSearchButton);
        verifyFieldsContainsPartText(mpnColumninSearchResults, "EDDIE0");
        goToLandingPage();

    }


}
