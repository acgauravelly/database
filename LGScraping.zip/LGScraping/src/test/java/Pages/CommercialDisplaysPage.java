package Pages;


public class CommercialDisplaysPage {
    private String hospitalPatientRoom = "http://www.lg.com/us/business/commercial-display/displays-tvs/healthcare/hospital-patient-room";
    private String proCentricSmartDisplays = "http://www.lg.com/us/business/commercial-display/displays-tvs/hospitality/procentric-smart-displays";
    private String proCentricValueDisplays = "http://www.lg.com/us/business/commercial-display/displays-tvs/hospitality/procentric-value-displays";
    private  String commercialLiteDisplays = "http://www.lg.com/us/business/commercial-display/displays-tvs/commercial-lite-displays";
    private    String hospitalityOledDisplays = "http://www.lg.com/us/business/commercial-display/displays-tvs/hospitality/hospitality-oled-displays";
    private    String headEndSystems = "http://www.lg.com/us/business/commercial-display/displays-tvs/hospitality/head-end-systems";
    private    String interfaceControls = "http://www.lg.com/us/business/commercial-display/displays-tvs/hospitality/interface-controls";



}
