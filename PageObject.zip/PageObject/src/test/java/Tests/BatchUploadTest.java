package Tests;

import Pages.LandingPage;
import Pages.ProductPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class BatchUploadTest {

    ProductPage productPage = new ProductPage();
    LandingPage landingPage = new LandingPage();

    @When("^I click Batch Upload button$")
    public void iClickBatchUploadButton() throws Throwable {
        productPage.deleteAnyAssetsOnProduct();
        landingPage.clickBatchUploadButton();
    }

    @And("^I am on Landing Page$")
    public void iAmOnLandingPage() throws Throwable {
        landingPage.verifyOnLandingPage();
    }

    @Then("^I should be able to do a Batch Upload of Assets$")
    public void iShouldBeAbleToDoABatchUploadOfAssets() throws Throwable {
        landingPage.batchUpload();
    }
}
