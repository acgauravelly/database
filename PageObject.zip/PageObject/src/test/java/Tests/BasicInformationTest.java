package Tests;

import Pages.ProductPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

/**
 * Created by ajay on 08/01/2017.
 */
public class BasicInformationTest {

    ProductPage productPage = new ProductPage();

    @And("^I click on edit$")
    public void iClickOnEdit() throws Throwable {
        productPage.edit();

    }

    @Then("^I should be able to edit the information$")
    public void iShouldBeAbleToEditTheInformation() throws Throwable {
        productPage.editBasicInfo("-Test Product");
    }

    @And("^I should be able to verify the updated info$")
    public void iShouldBeAbleToVerifyTheUpdatedInfo() throws Throwable {

        productPage.verifyUpdatedProductName();
    }
}
