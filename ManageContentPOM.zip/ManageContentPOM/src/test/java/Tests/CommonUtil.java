package Tests;


import Utils.WebConnector;

public class CommonUtil {

    public String url;
    WebConnector connector=new WebConnector();


}
