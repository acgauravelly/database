package Pages;

import org.junit.Assert;
import org.openqa.selenium.By;

public class ProductPage extends BasePage {


    private By inpageLink = By.cssSelector(".last>a");
    private By inpageStatus = By.cssSelector(".padd-rl");

    private By turnOffDownloadsCheckbox = By.cssSelector("input[name='download']");
    By editButton = By.cssSelector(".bt.btedit.tooltip-trigger-s.overlay-trigger-form>img");
    private By downloadButton = By.cssSelector(".bt.btright.tooltip-trigger-s");
    private By addtomyDownloads = By.cssSelector("#add_to_cart");
    private By downloadStatus = By.cssSelector(".alert.success_1");
    private By basicInfoLink = By.cssSelector(".padd>ul>li>a:nth-of-type(1)");
    private By productNameField = By.cssSelector(".detail-list-content-full");
    private By productNameFieldOnPopUp = By.cssSelector("input[name='titleList[]']");
    public String updatedProductName;

    //    Verify if the user is on the above product page
    public void verifyOnProductPage() {

        productPage();
    }

    //Verifying the newly added product
    public ProductPage verifyAddedProduct() {

        click(inpageLink);
        verifyTextofaField(inpageStatus, "No Inpage found");
        return new ProductPage();
    }


    public void deleteAnyAssetsOnProduct() throws InterruptedException {


//        Deletes if any assets are already present on the product
        verifyOnProductPage();
        clickImagesLink();
        deleteAssetIfPresent();
        clickVideosLink();
        deleteAssetIfPresent();


    }

    public void turnOffDownloadsOnProduct() {

        click(editButton);
        switchToIframe();
        uncheckCheckboxifSelected(turnOffDownloadsCheckbox);
        saveAndUpload();
    }

    public void addToCart() {
        click(downloadButton);
        click(addtomyDownloads);
        verifyFieldContainsText(downloadStatus, "successfully added to downloads cart!");
        goToLandingPage();

    }

    public void edit() {
        click(editButton);
    }

    public String editBasicInfo(String productName) throws InterruptedException {


        switchToIframe();
        clearField(productNameFieldOnPopUp);
        writetoField(productNameFieldOnPopUp, productName);
        clickCheckboxifNotSelected(turnOffDownloadsCheckbox);
        Thread.sleep(5000);
        saveAndUpdate();
        Thread.sleep(3000);
        swithcToDefaultPage();
        updatedProductName = productName;

        return updatedProductName;

    }

    public void verifyUpdatedProductName() throws InterruptedException {

        verifyFieldContainsText(productNameField, updatedProductName);
        Assert.assertFalse(isElementPresent(downloadButton));

//        Change the product name back as it is associated with other tests
        edit();
        editBasicInfo("Selenium Test");


    }


}
