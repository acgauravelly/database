package Tests;

import Pages.LandingPage;
import Pages.LoginPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class LoginPageTest {
    CommonUtil util = new CommonUtil();
    LoginPage loginPage = new LoginPage();
    LandingPage landingPage = new LandingPage();

    @Given("^Iam on login page$")
    public void iamOnLoginPage() throws Throwable {

        loginPage.loginPageUrl();

    }

    @And("^I login as \"([^\"]*)\" with \"([^\"]*)\"$")
    public void iLoginAsWith(String arg0, String arg1) throws Throwable {
        loginPage.logIn(arg0, arg1);

    }

    @Then("^I should be able to access landing page$")
    public void iShouldBeAbleToAccessHomePage() throws Throwable {
        landingPage.confirmTopMenuPresent();
    }
}
