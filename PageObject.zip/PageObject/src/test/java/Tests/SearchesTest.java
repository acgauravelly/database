package Tests;

import Pages.LandingPage;
import Pages.SearchesPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

/**
 * Created by ajay on 06/01/2017.
 */
public class SearchesTest {

    LandingPage landingPage = new LandingPage();
    SearchesPage searchesPage = new SearchesPage();

    @And("^Iam on landing page$")
    public void iamOnLandingPage() throws Throwable {
        landingPage.verifyOnLandingPage();

    }


    @And("^I click on \"([^\"]*)\" Search$")
    public void iClickOnSearch(String searchButton) throws Throwable {
        if (searchButton.equalsIgnoreCase("advanced")) {
            landingPage.clickAdvancedSearch();
        } else if (searchButton.equalsIgnoreCase("custom")) {
            landingPage.clickCustomSearch();
        }
    }


    @Then("^I should be able to search by \"([^\"]*)\"$")
    public void iShouldBeAbleToSearchBy(String typeOfSearch) throws Throwable {
        if (typeOfSearch.equalsIgnoreCase("mpn")) {
            searchesPage.searchByMpn();
        } else if (typeOfSearch.equalsIgnoreCase("ean")) {
            searchesPage.searchByEan();
        } else if (typeOfSearch.equalsIgnoreCase("Custom search")) {
            searchesPage.customSearch();
        } else if (typeOfSearch.equalsIgnoreCase("natural search")) {
            landingPage.naturalSearchbyBrand();
        }
    }

}
