package Tests;

import Pages.LandingPage;
import Pages.LoginPage;
import Pages.ProductPage;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class AddProductTest {
    LoginPage loginPage = new LoginPage();
    LandingPage landingPage = new LandingPage();
    ProductPage productPage = new ProductPage();

    @Given("^Iam logged in to MC$")
    public void iamLoggedInToMC() throws Throwable {

        loginPage.verifyLoggedin();
    }

    @And("^I add a new product with following$")
    public void iAddANewProductWithFollowing(DataTable table) throws Throwable {
        landingPage.addNewProduct(table);
    }

    @Then("^I should be able to see the product$")
    public void iShouldBeAbleToSeeTheProduct() throws Throwable {
        productPage.verifyAddedProduct();
    }


}
