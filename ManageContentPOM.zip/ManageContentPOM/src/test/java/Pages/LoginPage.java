package Pages;

import Utils.WebConnector;
import org.openqa.selenium.By;

public class LoginPage extends WebConnector {

    private String loginUrl = "https://dev-manage.flix360.com/";
    public static By email = By.id("email");
    private By password = By.id("password");
    private By signInButton = By.cssSelector("input[value='Sign in']");
    private By clickHere = By.linkText("click here");

    public void loginPageUrl() {
        openBrowser("Mozilla");
        navigate(loginUrl);
        assertTrueCondition("Not on login page", currentUrl().equalsIgnoreCase(loginUrl));

    }


    public void logIn(String emailaddress, String passwd) throws InterruptedException {
        writeToaField(email, emailaddress);
        writeToaField(password, passwd);
        click(signInButton);
        Thread.sleep(5000);


    }

    public void clickRequestAccessLink() {
        click(clickHere);

    }


}
