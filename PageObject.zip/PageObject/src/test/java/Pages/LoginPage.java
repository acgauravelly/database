package Pages;

import org.junit.Assert;
import org.openqa.selenium.By;

import static Utils.WebConnector.getCurrentDriver;


public class LoginPage extends BasePage {

    private By email = By.id("email");
    private By password = By.id("password");
    private By signInButton = By.xpath("//input[@name='sign']");
    private By iframePopUp = By.cssSelector("#fancybox-content");



    //Navigates to Login page
    public LoginPage navigateToLoginPage() throws InterruptedException {

        if (isLoggedIn()) {
            logOff();
            getCurrentDriver().get("http://dev-manage.flix360.com");
        }
        Assert.assertEquals("Login", getPageTitle());
        return new LoginPage();

    }

    //Does a Login with default credentials
    public LandingPage defaultLogin() throws InterruptedException {

        getCurrentDriver().get("http://dev-manage.flix360.com");
        Thread.sleep(5000);
        writetoField(email, "ajay@flixmedia.tv");
        writetoField(password, "Pass123");
        click(signInButton);
        Thread.sleep(5000);


        return new LandingPage();
    }

//    !isLoggedIn()&&
    public LandingPage verifyLoggedin() throws InterruptedException {
        if (isElementPresent(iframePopUp)) {
           goToLandingPage();
        }
        else{
            if(!isLoggedIn()) {
                defaultLogin();
            }
        }
        return new LandingPage();

    }

}
