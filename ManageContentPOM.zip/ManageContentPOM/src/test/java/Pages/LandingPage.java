package Pages;

import Utils.WebConnector;
import org.openqa.selenium.By;


public class LandingPage extends WebConnector {

    private By topMenu = By.cssSelector("div[class='masthead']");

    public void confirmTopMenuPresent() {

        isElementPresent(topMenu);
    }
}
