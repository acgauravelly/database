package Tests;

import Pages.ProductPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

/**
 * Created by ajay on 06/01/2017.
 */
public class AddToCartTest {

    ProductPage productPage = new ProductPage();

    @And("^Iam on product page$")
    public void iamOnProductPage() throws Throwable {
        productPage.verifyOnProductPage();
    }


    @Then("^I should be able to add the product to the cart$")
    public void iShouldBeAbleToDownloadTheProduct() throws Throwable {

        productPage.addToCart();
    }
}
