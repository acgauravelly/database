package Pages;

import Utils.WebConnector;
import org.openqa.selenium.By;

public class RequestAccessPage extends WebConnector {

    private By firstName = By.id("firstName");
    private By lastName = By.id("lastName");
    private By company = By.id("company");
    private By country = By.id("country");
    private By jobTitle = By.id("jobTitle");
    private By heardFrom = By.id("heardFrom");
    private By agency = By.cssSelector("select[id='represent']");
    private By agencyTitle = By.id("representText");
    private By englishLanguageCheckbox = By.cssSelector("#filter-language-1");
    private By reqAccessButton = By.cssSelector("input[value='Request Access']");
    private By reqAccessConfirmation=By.cssSelector(".box-header>h1");


    public void fillRequestAccessForm() {
        writeToaField(firstName, "Test");
        writeToaField(lastName, "LastName");
        writeToaField(LoginPage.email, "qa.automation@flixmedia.tv");
        writeToaField(company, "Test");
        select(country, "United Kingdom");
        writeToaField(jobTitle, "QA");
        writeToaField(heardFrom, "Test");
        select(agency, "Retailer");
        writeToaField(agencyTitle, "Test");
        click(englishLanguageCheckbox);
        click(reqAccessButton);

    }

    public void reqAccessConfirmation(){
        isElementDisplayed(reqAccessConfirmation);
        verifyTextofaField(reqAccessConfirmation,"Please verify your Email address");
    }

}
